with(doc2, tapply(RAGE, RSEX, mean))
with(doc2, mean(RAGE))
