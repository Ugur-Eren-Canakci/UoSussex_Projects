set.seed(26)

#### Data Analysis and Model Fitting ####
library("fitdistrplus")

# Data from WD
apple_data = read.csv("AAPL.csv")
amazon_data = read.csv("AMZN.csv")
alphabet_data = read.csv("GOOG.csv")
meta_data = read.csv("META.csv")
microsoft_data = read.csv("MSFT.csv")
nvidia_data = read.csv("NVDA.csv")

#Adjusted Close prices
apple_adj = apple_data$Adj.Close
apple_adj_return = (apple_adj[2:length(apple_adj)] - apple_adj[1:(length(apple_adj)-1)])/ apple_adj[1:(length(apple_adj)-1)]
apple_adj_ratio = log(apple_adj[2:length(apple_adj)]/ apple_adj[1:(length(apple_adj)-1)])

amazon_adj = amazon_data$Adj.Close
amazon_adj_return = (amazon_adj[2:length(apple_adj)] - amazon_adj[1:(length(apple_adj)-1)])/ amazon_adj[1:(length(apple_adj)-1)]
amazon_adj_ratio = log(amazon_adj[2:length(apple_adj)]/ amazon_adj[1:(length(apple_adj)-1)])

alphabet_adj = alphabet_data$Adj.Close
alphabet_adj_return = (alphabet_adj[2:length(apple_adj)] - alphabet_adj[1:(length(apple_adj)-1)])/ alphabet_adj[1:(length(apple_adj)-1)]
alphabet_adj_ratio = log(alphabet_adj[2:length(apple_adj)]/ alphabet_adj[1:(length(apple_adj)-1)])

meta_adj = meta_data$Adj.Close
meta_adj_return = (meta_adj[2:length(apple_adj)] - meta_adj[1:(length(apple_adj)-1)])/ meta_adj[1:(length(apple_adj)-1)]
meta_adj_ratio = log(meta_adj[2:length(apple_adj)]/ meta_adj[1:(length(apple_adj)-1)])

microsoft_adj = microsoft_data$Adj.Close
microsoft_adj_return = (microsoft_adj[2:length(apple_adj)] - microsoft_adj[1:(length(apple_adj)-1)])/ microsoft_adj[1:(length(apple_adj)-1)]
microsoft_adj_ratio = log(microsoft_adj[2:length(apple_adj)]/ microsoft_adj[1:(length(apple_adj)-1)])

nvidia_adj = nvidia_data$Adj.Close
nvidia_adj_return = (nvidia_adj[2:length(apple_adj)] - nvidia_adj[1:(length(apple_adj)-1)])/ nvidia_adj[1:(length(apple_adj)-1)]
nvidia_adj_ratio = log(nvidia_adj[2:length(apple_adj)]/ nvidia_adj[1:(length(apple_adj)-1)])


#### Log-normal Ratio Model ####
install.packages("fitdistrplus")
library(fitdistrplus)

#Log-normal Ratio Model on the first 30 days

print("apple lognormal ratio estimates: ");lognorm_model_apple = fitdist(apple_adj_ratio[1:30], distr = "norm")
print(lognorm_model_apple)
print("amazon lognormal ratio estimates: ");lognorm_model_amazon = fitdist(amazon_adj_ratio[1:30], distr = "norm") 
print(lognorm_model_amazon)
print("alphabet lognormal ratio estimates:");lognorm_model_alphabet = fitdist(alphabet_adj_ratio[1:30], distr = "norm")
print(lognorm_model_alphabet)
print("meta lognormal ratio estimates:");lognorm_model_meta = fitdist(meta_adj_ratio[1:30], distr = "norm")
print(lognorm_model_meta)
print("microsoft lognormal ratio estimates:");lognorm_model_microsoft = fitdist(microsoft_adj_ratio[1:30], distr = "norm")
print(lognorm_model_microsoft)
print("nvidia lognormal ratio estimates:");lognorm_model_nvidia = fitdist(nvidia_adj_ratio[1:30], distr = "norm")
print(lognorm_model_nvidia)

##Lognormal Estimations on day 31

lognorm_estimate_apple = rnorm(n=1, mean=lognorm_model_apple$estimate[1], sd=lognorm_model_apple$estimate[2])
lognorm_estimate_amazon = rnorm(n=1, mean=lognorm_model_amazon$estimate[1], sd=lognorm_model_amazon$estimate[2])
lognorm_estimate_alphabet = rnorm(n=1, mean=lognorm_model_alphabet$estimate[1], sd=lognorm_model_alphabet$estimate[2])
lognorm_estimate_meta = rnorm(n=1, mean=lognorm_model_meta$estimate[1], sd=lognorm_model_meta$estimate[2])
lognorm_estimate_microsoft = rnorm(n=1, mean=lognorm_model_microsoft$estimate[1], sd=lognorm_model_microsoft$estimate[2])
lognorm_estimate_nvidia = rnorm(n=1, mean=lognorm_model_nvidia$estimate[1], sd=lognorm_model_nvidia$estimate[2])

cat("apple lognorm estimated mean:", lognorm_model_apple$estimate[1])
cat("amazon lognorm estimated mean:", lognorm_model_amazon$estimate[1])
cat("alphabet lognorm estimated mean:", lognorm_model_alphabet$estimate[1])
cat("meta lognorm estimated mean:", lognorm_model_meta$estimate[1])
cat("microsoft lognorm estimated mean:", lognorm_model_microsoft$estimate[1])
cat("nvidia lognorm estimated mean:", lognorm_model_nvidia$estimate[1])

###Single estimations
lognorm_apple_value_31 = apple_data$Adj.Close[30]*exp(lognorm_estimate_apple)
cat("day 31 lognorm estimate for apple:",lognorm_apple_value_31,"\n")
cat("the actual day 31 value of apple:", apple_data$Adj.Close[31],"\n")
cat("and the day 30 value of apple:", apple_data$Adj.Close[30],"\n")

lognorm_amazon_value_31 = amazon_data$Adj.Close[30]*exp(lognorm_estimate_amazon)
cat("day 31 lognorm estimate for amazon:",lognorm_amazon_value_31,"\n")
cat("the actual day 31 value of amazon:", amazon_data$Adj.Close[31],"\n")
cat("and the day 30 value of amazon:", amazon_data$Adj.Close[30],"\n")

lognorm_alphabet_value_31 = alphabet_data$Adj.Close[30]*exp(lognorm_estimate_alphabet)
cat("day 31 lognorm estimate for alphabet:",lognorm_alphabet_value_31,"\n")
cat("the actual day 31 value of alphabet:", alphabet_data$Adj.Close[31],"\n")
cat("and the day 30 value of alphabet:", alphabet_data$Adj.Close[30],"\n")

lognorm_meta_value_31 = meta_data$Adj.Close[30]*exp(lognorm_estimate_meta)
cat("day 31 lognorm estimate for meta:",lognorm_meta_value_31,"\n")
cat("the actual day 31 value of meta:", meta_data$Adj.Close[31],"\n")
cat("and the day 30 value of meta:", meta_data$Adj.Close[30],"\n")

lognorm_nvidia_value_31 = nvidia_data$Adj.Close[30]*exp(lognorm_estimate_nvidia)
cat("day 31 lognorm estimate for nvidia:",lognorm_nvidia_value_31,"\n")
cat("and the day 30 value of nvidia:", nvidia_data$Adj.Close[30],"\n")

###Multiple estimations
lognorm_estimate_amount = 5
lognorm_estimates = matrix(rep(0, 6*lognorm_estimate_amount), byrow = TRUE, nrow = 6)
A = lognorm_estimates
for (i in 1:lognorm_estimate_amount){
  A[1,i] =  rnorm(n=1, mean=lognorm_model_apple$estimate[1], sd=lognorm_model_apple$estimate[2])
}

for (i in 1:lognorm_estimate_amount){
  A[2,i] =  rnorm(n=1, mean=lognorm_model_amazon$estimate[1], sd=lognorm_model_amazon$estimate[2])
}

for (i in 1:lognorm_estimate_amount){
  A[3,i] =  rnorm(n=1, mean=lognorm_model_alphabet$estimate[1], sd=lognorm_model_alphabet$estimate[2])
}

for (i in 1:lognorm_estimate_amount){
  A[4,i] =  rnorm(n=1, mean=lognorm_model_meta$estimate[1], sd=lognorm_model_meta$estimate[2])
}

for (i in 1:lognorm_estimate_amount){
  A[5,i] =  rnorm(n=1, mean=lognorm_model_microsoft$estimate[1], sd=lognorm_model_microsoft$estimate[2])
}

for (i in 1:lognorm_estimate_amount){
  A[6,i] =  rnorm(n=1, mean=lognorm_model_nvidia$estimate[1], sd=lognorm_model_nvidia$estimate[2])
}
lognorm_estimates = A; lognorm_estimates
lognorm_estimates


#### Autoregressive Model ####
library(stats)
install.packages("stats")

#Model fitting over number of days
set.seed(26)
ar_days = 29
help(ar)

#First 29 returns are taken into the model => First 30 days are used in the calculations
apple_ar_model=ar.ols(apple_adj_return[1:ar_days])
print("apple autoregression results:");apple_ar_model
apple_ar_model$ar
apple_ar_model$x.intercept

amazon_ar_model=ar.ols(amazon_adj_return[1:ar_days])
print("amazon autoregression results:");amazon_ar_model
amazon_ar_model$ar
amazon_ar_model$x.intercept

alphabet_ar_model=ar.ols(alphabet_adj_return[1:ar_days])
print("alphabet autoregression results:");alphabet_ar_model
alphabet_ar_model$ar
alphabet_ar_model$x.intercept

meta_ar_model=ar.ols(meta_adj_return[1:ar_days])
print("meta autoregression results:");meta_ar_model
meta_ar_model$ar
meta_ar_model$x.intercept

microsoft_ar_model=ar.ols(microsoft_adj_return[1:ar_days])
print("microsoft autoregression results:");microsoft_ar_model
microsoft_ar_model$ar
microsoft_ar_model$x.intercept

nvidia_ar_model=ar.ols(nvidia_adj_return[1:ar_days])
print("nvidia autoregression results:");nvidia_ar_model
nvidia_ar_model$ar
nvidia_ar_model$x.intercept

#### Autoregressive Estimations on day 31 ####

apple_ar_length = length(apple_ar_model$ar); apple_ar_length
amazon_ar_length = length(amazon_ar_model$ar);amazon_ar_length
alphabet_ar_length = length(alphabet_ar_model$ar);alphabet_ar_length
meta_ar_length = length(meta_ar_model$ar);meta_ar_length
microsoft_ar_length = length(microsoft_ar_model$ar);microsoft_ar_length
nvidia_ar_length = length(nvidia_ar_model$ar);nvidia_ar_length

apple_ar_estimate = (apple_ar_model$x.intercept 
                     + (apple_adj_return[(ar_days - apple_ar_length + 1):ar_days]
                        -apple_ar_model$x.intercept)
                     %*%apple_ar_model$ar)
amazon_ar_estimate = (amazon_ar_model$x.intercept 
                     + (amazon_adj_return[(ar_days - amazon_ar_length + 1):ar_days]
                        -amazon_ar_model$x.intercept )
                     %*%amazon_ar_model$ar)
alphabet_ar_estimate = (alphabet_ar_model$x.intercept 
                     + (alphabet_adj_return[(ar_days - alphabet_ar_length + 1):ar_days]
                        -alphabet_ar_model$x.intercept)
                     %*%alphabet_ar_model$ar)
meta_ar_estimate = (meta_ar_model$x.intercept 
                    + (meta_adj_return[(ar_days - meta_ar_length + 1):ar_days]
                        -meta_ar_model$x.intercept)
                    %*%meta_ar_model$ar)
microsoft_ar_estimate = (microsoft_ar_model$x.intercept 
                     + (microsoft_adj_return[(ar_days - microsoft_ar_length + 1):ar_days]
                        -microsoft_ar_model$x.intercept )
                     %*%microsoft_ar_model$ar)
nvidia_ar_estimate = (nvidia_ar_model$x.intercept 
                     + (nvidia_adj_return[(ar_days - nvidia_ar_length + 1):ar_days]
                        -nvidia_ar_model$x.intercept )
                     %*%nvidia_ar_model$ar)
apple_ar_estimate

#### Estimation data storage ####

#ar_days necessary to signify on how many days the model was built on.
ar_days
ar_estimated_returns = matrix(rep(x=0, times=6*(60-ar_days-1)), byrow=TRUE, nrow=6)
#The initial vector has to be set for the script to work.
ar_estimated_returns[, 1] = c(apple_ar_estimate, amazon_ar_estimate, alphabet_ar_estimate, 
                             meta_ar_estimate, microsoft_ar_estimate, nvidia_ar_estimate)
ar_estimated_returns
for (i in 2:(ar_days+1)) {
  
  cat("Iteration Number:", i)
  apple_ar_model=ar.ols(c(apple_adj_return[1:ar_days],
                          ar_estimated_returns[1,1:(i-1)])); apple_ar_model
  
  amazon_ar_model=ar.ols(c(amazon_adj_return[1:ar_days],
                           ar_estimated_returns[2,1:(i-1)]))
  
  alphabet_ar_model=ar.ols(c(alphabet_adj_return[1:ar_days],
                             ar_estimated_returns[3,1:(i-1)]))
  
  meta_ar_model=ar.ols(c(meta_adj_return[1:ar_days],
                         ar_estimated_returns[4,1:(i-1)]))
  
  microsoft_ar_model=ar.ols(c(microsoft_adj_return[1:ar_days],
                              ar_estimated_returns[5,1:(i-1)]))
  
  nvidia_ar_model=ar.ols(c(nvidia_adj_return[1:ar_days],
                           ar_estimated_returns[6,1:(i-1)]))

  
  apple_ar_length = length(apple_ar_model$ar)
  
  amazon_ar_length = length(amazon_ar_model$ar)
  
  alphabet_ar_length = length(alphabet_ar_model$ar)
  
  meta_ar_length = length(meta_ar_model$ar)
  
  microsoft_ar_length = length(microsoft_ar_model$ar)
  
  nvidia_ar_length = length(nvidia_ar_model$ar)
  
  if (apple_ar_length == 0) {apple_ar_estimate = apple_ar_model$x.intercept}
  else if (i > apple_ar_length) {
    new_returns_vector_apple = ar_estimated_returns[1,((i - apple_ar_length):(i-1))]  
    apple_ar_estimate = (apple_ar_model$x.intercept + new_returns_vector_apple%*%apple_ar_model$ar)
    
  }
  else {
    new_returns_vector_apple = c(apple_adj_return[(ar_days-(apple_ar_length-(i-1))+1):ar_days],
                                 ar_estimated_returns[1,1:(i-1)])
    apple_ar_estimate = (apple_ar_model$x.intercept + new_returns_vector_apple%*%apple_ar_model$ar)
    
  }
  
  if (amazon_ar_length == 0) {amazon_ar_estimate = amazon_ar_model$x.intercept}
  else if (i > amazon_ar_length) {
    new_returns_vector_amazon = ar_estimated_returns[2,((i - amazon_ar_length):(i-1))]
    amazon_ar_estimate = (amazon_ar_model$x.intercept + new_returns_vector_amazon%*%amazon_ar_model$ar)
    
  }
  else {
    new_returns_vector_amazon = c(amazon_adj_return[(ar_days-(amazon_ar_length-(i-1))+1):ar_days],
                                 ar_estimated_returns[2,1:(i-1)])
    amazon_ar_estimate = (amazon_ar_model$x.intercept + new_returns_vector_amazon%*%amazon_ar_model$ar)
    
  }
  
  if (alphabet_ar_length == 0) {alphabet_ar_estimate = alphabet_ar_model$x.intercept}
  else if (i > alphabet_ar_length) {
    new_returns_vector_alphabet = ar_estimated_returns[3,((i - alphabet_ar_length):(i-1))]
    alphabet_ar_estimate = (alphabet_ar_model$x.intercept + new_returns_vector_alphabet%*%alphabet_ar_model$ar)
    
  }
  else {
    new_returns_vector_alphabet = c(alphabet_adj_return[(ar_days-(alphabet_ar_length-(i-1))+1):ar_days],
                                 ar_estimated_returns[3,1:(i-1)])
    alphabet_ar_estimate = (alphabet_ar_model$x.intercept + new_returns_vector_alphabet%*%alphabet_ar_model$ar)
    
  }
  if (meta_ar_length == 0) {meta_ar_estimate = meta_ar_model$x.intercept}
  else if (i > meta_ar_length) {
    new_returns_vector_meta = ar_estimated_returns[4,((i - meta_ar_length):(i-1))]
    meta_ar_estimate = (meta_ar_model$x.intercept + new_returns_vector_meta%*%meta_ar_model$ar)

  }
  else {
    new_returns_vector_meta = c(meta_adj_return[(ar_days-(meta_ar_length-(i-1))+1):ar_days],
                                 ar_estimated_returns[4,1:(i-1)])
    meta_ar_estimate = (meta_ar_model$x.intercept + new_returns_vector_meta%*%meta_ar_model$ar)
    
  }
  
  if (microsoft_ar_length == 0) {microsoft_ar_estimate = microsoft_ar_model$x.intercept}
  else if (i > microsoft_ar_length) {
    new_returns_vector_microsoft = ar_estimated_returns[5,((i - microsoft_ar_length):(i-1))]
    microsoft_ar_estimate = (microsoft_ar_model$x.intercept + new_returns_vector_microsoft%*%microsoft_ar_model$ar)

  }
  else {
    new_returns_vector_microsoft = c(microsoft_adj_return[(ar_days-(microsoft_ar_length-(i-1))+1):ar_days],
                                     ar_estimated_returns[5,1:(i-1)])
    microsoft_ar_estimate = (microsoft_ar_model$x.intercept + new_returns_vector_microsoft%*%microsoft_ar_model$ar)
  }
  
  if (nvidia_ar_length == 0) {nvidia_ar_estimate = nvidia_ar_model$x.intercept}
  else if (i > nvidia_ar_length) {
    new_returns_vector_nvidia = ar_estimated_returns[6,((i - nvidia_ar_length):(i-1))]
    nvidia_ar_estimate = (nvidia_ar_model$x.intercept + new_returns_vector_nvidia%*%nvidia_ar_model$ar)
  }
  else {
    new_returns_vector_nvidia = c(nvidia_adj_return[(ar_days-(nvidia_ar_length-(i-1))+1):ar_days],
                                 ar_estimated_returns[6,1:(i-1)])
    nvidia_ar_estimate = (nvidia_ar_model$x.intercept + new_returns_vector_nvidia%*%nvidia_ar_model$ar)
  }

  ar_estimated_returns[, i] = c(apple_ar_estimate, amazon_ar_estimate, alphabet_ar_estimate, 
                               meta_ar_estimate, microsoft_ar_estimate, nvidia_ar_estimate)
};print(ar_estimated_returns) #column length is 6 => rows represent companies,
#columns represent estimations
print(ar_estimated_returns)

#### Linear Regression Model Fitting #### (not used in the paper)

#First 30 days
mlr_model_apple_first30 = lm(apple_adj[1:30] ~ amazon_adj[1:30] 
                                             + alphabet_adj[1:30] 
                                             + meta_adj[1:30] 
                                             + microsoft_adj[1:30] 
                                             + nvidia_adj[1:30])
summary(mlr_model_apple_first30)
#Refined model for apple
mlr_model_apple_first30_new = lm(apple_adj[1:30] ~ amazon_adj[1:30] 
                                                 + alphabet_adj[1:30] 
                                                 + microsoft_adj[1:30])
summary(mlr_model_apple_first30_new) 
mlr_model_apple_first30_new$coefficients

#Comparison of two models
anova(mlr_model_apple_first30,mlr_model_apple_first30_new)
#F-value too big => No significant effect on the results by dropping Meta and Nvidia variables,
#yet it makes the simulation process easier, so the new model is useful.


mlr_model_amazon = lm(amazon_adj ~ apple_adj + alphabet_adj + meta_adj + microsoft_adj + nvidia_adj)
summary(mlr_model_amazon)

mlr_model_alphabet = lm(alphabet_adj ~ apple_adj + amazon_adj + meta_adj + microsoft_adj + nvidia_adj)
summary(mlr_model_alphabet)

mlr_model_meta = lm(meta_adj ~ apple_adj + amazon_adj + alphabet_adj + microsoft_adj + nvidia_adj)
summary(mlr_model_meta)

mlr_model_microsoft = lm(microsoft_adj ~ apple_adj + amazon_adj + alphabet_adj + meta_adj + nvidia_adj)
summary(mlr_model_microsoft)

mlr_model_nvidia = lm(nvidia_adj ~ apple_adj + amazon_adj + alphabet_adj + meta_adj + microsoft_adj)
summary(mlr_model_nvidia)


#### Importance Distributions ####

#Autoregression-Importance
ar_estimated_day = 31

ar_importance_long = rep(0,6)
ar_importance_short = rep(0,6)

for (i in 1:6){
  z = cumsum(ar_estimated_returns[i,1:(ar_estimated_day-30)])
  if (z[(ar_estimated_day-30)] > 0){
    ar_importance_long[i] = z[(ar_estimated_day-30)]
  } else {
    ar_importance_short[i] = z[(ar_estimated_day-30)]
  }
}

ar_importance_long = ar_importance_long/sum(ar_importance_long);cat(ar_importance_long)
ar_importance_short = ar_importance_short/sum(ar_importance_short);cat(ar_importance_short)

ar_importance_long; ar_importance_short


#Log-normal Importance

#In the matrices below, rows are companies and columns are simulations
lognorm_importance_long_matrix = matrix(rep(0,6*lognorm_estimate_amount), byrow=TRUE, nrow=6)
lognorm_importance_short_matrix = matrix(rep(0,6*lognorm_estimate_amount), byrow=TRUE, nrow=6)

#lognorm_estimates is necessary for the rest to work.

for(i in 1:lognorm_estimate_amount) {
  for(j in 1:6){
    if (lognorm_estimates[j,i] > 0){
      lognorm_importance_long_matrix[j,i] = lognorm_estimates[j,i]
    } else {
      lognorm_importance_short_matrix[j,i] = lognorm_estimates[j,i]
    }
  } 
}

for(i in 1:lognorm_estimate_amount){
  lognorm_importance_long_matrix[,i] = (lognorm_importance_long_matrix[,i]
                                        /sum(lognorm_importance_long_matrix[,i]))
  lognorm_importance_short_matrix[,i] = (lognorm_importance_short_matrix[,i]
                                         /sum(lognorm_importance_short_matrix[,i]))
}
lognorm_importance_long_matrix
lognorm_importance_short_matrix


#### Portfolio Simulation ####

#Simple sampling 
buy_assets_random = function(number=100){
  
  assets_random = rep(0, 12)
  
  for(i in 1:number){
    a = sample(1:12, size=1)
    assets_random[a] = assets_random[a] + 1
  }
  return(assets_random)
}

random_portfolios = matrix(rep(0, 12*100), byrow=TRUE, nrow=100)

for(i in 1:100) {
  a = buy_assets_random()
  random_portfolios[i,] = a
}; print(random_portfolios)


#Log-Normal Sampling

#lognorm_importance_long_matrix and lognorm_importance_long_matrix are necessary 
#in these vectors, rows should be companies and columns should be simulations
#Form 50 long, 50 short positions with each different log-norm importance distributions

#Log-Normal Portfolios for day 31
lognorm_portfolios_day31 = matrix(rep(0, 12*lognorm_estimate_amount), byrow=TRUE, nrow=12)
for (i in 1:lognorm_estimate_amount){
  for(j in 1:50){
    asset_long = sample(1:6, size=1, prob = lognorm_importance_long_matrix[,i])
    lognorm_portfolios_day31[asset_long,i] = lognorm_portfolios_day31[asset_long,i] + 1
  }
  for(j in 1:50){
    asset_short = sample(7:12, size=1, prob = lognorm_importance_short_matrix[,i])
    lognorm_portfolios_day31[asset_short,i] = lognorm_portfolios_day31[asset_short,i] + 1
    }
};print(lognorm_portfolios_day31)

#Autoregressive Sampling
#ar_importance_long,ar_importance_short necessary
#ar_estimated_day necessary since ar_importance_long and ar_importance_short
#was created using this value. For now, importance vectors are created with 
ar_estimated_day

#Portfolio sampling on day "ar_estimated_day"
ar_portfolio_estimated_day = rep(0, 12)
ar_importance_long;ar_importance_short
for(i in 1:50){
  asset_long = sample(1:6, size=1, prob=ar_importance_long)
  ar_portfolio_estimated_day[asset_long] = ar_portfolio_estimated_day[asset_long] + 1
  asset_short = sample(7:12, size=1, prob=ar_importance_short)
  ar_portfolio_estimated_day[asset_short] = ar_portfolio_estimated_day[asset_short] + 1
}; ar_portfolio_estimated_day

#### Results and Comparison ####
#ar portfolio sampling not finished!!!!!!!!!!!!!!!!!!!!
#Simple Sampled Portfolios Resulting Values
#100 portfolios => 100 results

#random_portfolios is necessary, rows are portfolios and columns are number of long and short positions for 
#each company, columns 1:6 are long positions, 7:12 are short positions
random_portfolios
#Day n Results
n=31
#From each portfolio, I get a payoff value on the estimated day and an investment amount on day 30
random_portfolio_long_payoffs = rep(0, 100)
random_portfolio_long_investments = rep(0,100)
 
#Payoff on the estimated day n
for (i in 1:length(random_portfolios[,1])){
  u = 0
  u = u + random_portfolios[i,1]*apple_adj[n]
  u = u + random_portfolios[i,2]*amazon_adj[n]
  u = u + random_portfolios[i,3]*alphabet_adj[n]
  u = u + random_portfolios[i,4]*meta_adj[n]
  u = u + random_portfolios[i,5]*microsoft_adj[n]
  u = u + random_portfolios[i,6]*nvidia_adj[n]
  random_portfolio_long_payoffs[i] = u
}

#Investment on day 30
for (i in 1:length(random_portfolios[,1])){
  u = 0
  u = u + random_portfolios[i,1]*apple_adj[30]
  u = u + random_portfolios[i,2]*amazon_adj[30]
  u = u + random_portfolios[i,3]*alphabet_adj[30]
  u = u + random_portfolios[i,4]*meta_adj[30]
  u = u + random_portfolios[i,5]*microsoft_adj[30]
  u = u + random_portfolios[i,6]*nvidia_adj[30]
  random_portfolio_long_investments[i] = u
}

random_long_profits = random_portfolio_long_payoffs - random_portfolio_long_investments 
cat("positive payoffs from the long positions on day 31:",random_long_profits[which(random_long_profits>0)]) 
cat("negative payoffs from the long positions on day 31:",random_long_profits[which(random_long_profits<0)]) 

#mean of the profits
mean(random_long_profits[which(random_long_profits>0)])
#mean of the losses
mean(random_long_profits[which(random_long_profits<0)])

#Short portfolio profits
random_portfolio_short_payoffs = rep(0, 100)
random_portfolio_short_investments = rep(0,100)


#Payoff on the estimated day n
for (i in 1:length(random_portfolios[,1])){
  u = 0
  u = u + random_portfolios[i,7]*apple_adj[n]
  u = u + random_portfolios[i,8]*amazon_adj[n]
  u = u + random_portfolios[i,9]*alphabet_adj[n]
  u = u + random_portfolios[i,10]*meta_adj[n]
  u = u + random_portfolios[i,11]*microsoft_adj[n]
  u = u + random_portfolios[i,12]*nvidia_adj[n]
  random_portfolio_short_payoffs[i] = u
}

#Investment on day 30
for (i in 1:length(random_portfolios[,1])){
  u = 0
  u = u + random_portfolios[i,7]*apple_adj[30]
  u = u + random_portfolios[i,8]*amazon_adj[30]
  u = u + random_portfolios[i,9]*alphabet_adj[30]
  u = u + random_portfolios[i,10]*meta_adj[30]
  u = u + random_portfolios[i,11]*microsoft_adj[30]
  u = u + random_portfolios[i,12]*nvidia_adj[30]
  random_portfolio_short_investments[i] = u
}

#Important caution: since short stocks are borrowed and sold, we gain money on day 30
#and give a stock back at the estimation day. Hence, the profit is calculated by 

random_short_profits = random_portfolio_short_investments - random_portfolio_short_payoffs 
cat("positive payoffs from the short positions on day 31:",random_short_profits[which(random_short_profits>0)]) 
cat("negative payoffs from the short positions on day 31:",random_short_profits[which(random_short_profits<0)]) 

#mean of the profits
mean(random_short_profits[which(random_short_profits>0)])
#mean of the losses
mean(random_short_profits[which(random_short_profits<0)])


#Log-Normal Payoffs on day 31
lognorm_portfolios_day31 #necessary 

#Long profits/losses
lognorm_long_payoffs = rep(0, length(lognorm_portfolios_day31[1,]))
lognorm_long_investment = rep(0, length(lognorm_portfolios_day31[1,]))

for(i in 1:length(lognorm_long_investment)){
  u = 0
  u = u + lognorm_portfolios_day31[1,i]*apple_adj[31] 
  u = u + lognorm_portfolios_day31[2,i]*amazon_adj[31] 
  u = u + lognorm_portfolios_day31[3,i]*alphabet_adj[31] 
  u = u + lognorm_portfolios_day31[4,i]*meta_adj[31] 
  u = u + lognorm_portfolios_day31[5,i]*microsoft_adj[31] 
  u = u + lognorm_portfolios_day31[6,i]*nvidia_adj[31] 
  lognorm_long_payoffs[i] = u
}
for(i in 1:length(lognorm_long_investment)){
  u = 0
  u = u + lognorm_portfolios_day31[1,i]*apple_adj[30] 
  u = u + lognorm_portfolios_day31[2,i]*amazon_adj[30] 
  u = u + lognorm_portfolios_day31[3,i]*alphabet_adj[30] 
  u = u + lognorm_portfolios_day31[4,i]*meta_adj[30] 
  u = u + lognorm_portfolios_day31[5,i]*microsoft_adj[30] 
  u = u + lognorm_portfolios_day31[6,i]*nvidia_adj[30] 
  lognorm_long_investment[i] = u
}
lognorm_long_profits = lognorm_long_payoffs - lognorm_long_investment
cat("positive payoffs from the lognorm long positions on day 31:",lognorm_long_profits[which(lognorm_long_profits>0)]) 
cat("negative payoffs from the lognorm long positions on day 31:",lognorm_long_profits[which(lognorm_long_profits<0)]) 

#mean of the profits
mean(lognorm_long_profits[which(lognorm_long_profits>0)])
#mean of the losses
mean(lognorm_long_profits[which(lognorm_long_profits<0)])

#Short profits/losses

lognorm_short_payoffs = rep(0, length(lognorm_portfolios_day31[1,]))
lognorm_short_investment = rep(0, length(lognorm_portfolios_day31[1,]))

for(i in 1:length(lognorm_short_investment)){
  u = 0
  u = u + lognorm_portfolios_day31[7,i]*apple_adj[31] 
  u = u + lognorm_portfolios_day31[8,i]*amazon_adj[31] 
  u = u + lognorm_portfolios_day31[9,i]*alphabet_adj[31] 
  u = u + lognorm_portfolios_day31[10,i]*meta_adj[31] 
  u = u + lognorm_portfolios_day31[11,i]*microsoft_adj[31] 
  u = u + lognorm_portfolios_day31[12,i]*nvidia_adj[31] 
  lognorm_short_payoffs[i] = u
}
for(i in 1:length(lognorm_short_investment)){
  u = 0
  u = u + lognorm_portfolios_day31[7,i]*apple_adj[30] 
  u = u + lognorm_portfolios_day31[8,i]*amazon_adj[30] 
  u = u + lognorm_portfolios_day31[9,i]*alphabet_adj[30] 
  u = u + lognorm_portfolios_day31[10,i]*meta_adj[30] 
  u = u + lognorm_portfolios_day31[11,i]*microsoft_adj[30] 
  u = u + lognorm_portfolios_day31[12,i]*nvidia_adj[30] 
  lognorm_short_investment[i] = u
}
lognorm_short_profits = lognorm_short_investment - lognorm_short_payoffs
cat("profits from the lognorm short positions on day 31:",lognorm_short_profits[which(lognorm_short_profits>0)]) 
cat("losses payoffs from the lognorm short positions on day 31:",lognorm_short_profits[which(lognorm_short_profits<0)]) 

#mean of the profits
mean(lognorm_short_profits[which(lognorm_short_profits>0)])
#mean of the losses
mean(lognorm_short_profits[which(lognorm_short_profits<0)])

#Autoregressive Payoffs

#ar_portfolio_estimated_day necessary, holds the positions for each type of asset
ar_portfolio_estimated_day

#Long positions
#Total value of the long positions on the estimated
ar_long_payoff_estimated_day = 0
ar_long_payoff_estimated_day = ar_long_payoff_estimated_day  + ar_portfolio_estimated_day[1]*apple_adj[33]
ar_long_payoff_estimated_day = ar_long_payoff_estimated_day  + ar_portfolio_estimated_day[2]*amazon_adj[33]
ar_long_payoff_estimated_day = ar_long_payoff_estimated_day  + ar_portfolio_estimated_day[3]*alphabet_adj[33]
ar_long_payoff_estimated_day = ar_long_payoff_estimated_day  + ar_portfolio_estimated_day[4]*meta_adj[33]
ar_long_payoff_estimated_day = ar_long_payoff_estimated_day  + ar_portfolio_estimated_day[5]*microsoft_adj[33]
ar_long_payoff_estimated_day = ar_long_payoff_estimated_day  + ar_portfolio_estimated_day[6]*nvidia_adj[33]
ar_long_payoff_estimated_day 
#Total value of the long positions on day 30
ar_long_payoff_day30 = 0
ar_long_payoff_day30 = ar_long_payoff_day30  + ar_portfolio_estimated_day[1]*apple_adj[30]
ar_long_payoff_day30 = ar_long_payoff_day30  + ar_portfolio_estimated_day[2]*amazon_adj[30]
ar_long_payoff_day30 = ar_long_payoff_day30  + ar_portfolio_estimated_day[3]*alphabet_adj[30]
ar_long_payoff_day30 = ar_long_payoff_day30  + ar_portfolio_estimated_day[4]*meta_adj[30]
ar_long_payoff_day30 = ar_long_payoff_day30  + ar_portfolio_estimated_day[5]*microsoft_adj[30]
ar_long_payoff_day30 = ar_long_payoff_day30  + ar_portfolio_estimated_day[6]*nvidia_adj[30]
ar_long_payoff_day30 

ar_long_profit = ar_long_payoff_estimated_day - ar_long_payoff_day30; 
cat("profit from the ar long position on the estimated day:",ar_long_profit[which(ar_long_profit>0)]) 
cat("loss from the ar long position on the estimated day:",ar_long_profit[which(ar_long_profit<0)]) 

#Short positions
#Total value of the short positions on estimated_day
ar_short_payoff_estimated_day = 0
ar_short_payoff_estimated_day = ar_short_payoff_estimated_day  + ar_portfolio_estimated_day[7]*apple_adj[33]
ar_short_payoff_estimated_day = ar_short_payoff_estimated_day  + ar_portfolio_estimated_day[8]*amazon_adj[33]
ar_short_payoff_estimated_day = ar_short_payoff_estimated_day  + ar_portfolio_estimated_day[9]*alphabet_adj[33]
ar_short_payoff_estimated_day = ar_short_payoff_estimated_day  + ar_portfolio_estimated_day[10]*meta_adj[33]
ar_short_payoff_estimated_day = ar_short_payoff_estimated_day  + ar_portfolio_estimated_day[11]*microsoft_adj[33]
ar_short_payoff_estimated_day = ar_short_payoff_estimated_day  + ar_portfolio_estimated_day[12]*nvidia_adj[33]
ar_short_payoff_estimated_day 
#Total value of the short positions on day 
ar_short_payoff_day30 = 0
ar_short_payoff_day30 = ar_short_payoff_day30  + ar_portfolio_estimated_day[7]*apple_adj[30]
ar_short_payoff_day30 = ar_short_payoff_day30  + ar_portfolio_estimated_day[8]*amazon_adj[30]
ar_short_payoff_day30 = ar_short_payoff_day30  + ar_portfolio_estimated_day[9]*alphabet_adj[30]
ar_short_payoff_day30 = ar_short_payoff_day30  + ar_portfolio_estimated_day[10]*meta_adj[30]
ar_short_payoff_day30 = ar_short_payoff_day30  + ar_portfolio_estimated_day[11]*microsoft_adj[30]
ar_short_payoff_day30 = ar_short_payoff_day30  + ar_portfolio_estimated_day[12]*nvidia_adj[30]
ar_short_payoff_day30 

#Because short stocks are borrowed, the payoff comes from the day 30 borrowings, and the stock
#will be returned on the estimated day
ar_short_profit = ar_short_payoff_day30 - ar_short_payoff_estimated_day 
cat("profits from the ar short positions on estimated day:",ar_short_profit[which(ar_short_profit>0)]) 
cat("losses from the ar short positions on estimated day:",ar_short_profit[which(ar_short_profit<0)]) 